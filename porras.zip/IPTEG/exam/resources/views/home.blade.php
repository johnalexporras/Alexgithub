@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Dashboard') }}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    {{ __('You are logged in!') }}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

<div><html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>FINAL</title>
    </head>
    <body>
        <p>
        <p></p> <BR>
            <div class="row">
        <div class="mt-2 text-gray-600 dark:text-gray-400 text-sm", style="margin-left:15cm">
            <h1>Narrative Report 
            </h1>
        </div>
            <div class="mt-2 text-gray-600 dark:text-gray-400 text-sm", style="margin-left:1m">
         <div>
             <p>

             </p>
         </div>
         <div class=" ",
                style="text-align: justify;display: block;font-size: 1m;"> 
         </div>
            </div>
       Hadoop is one of the frameworks that may be used to construct distributed computing applications. <br>
        When we talk about Hadoop, there are two primary components that make up its core: <br>
         The first is the Hadoop distributed file system, which is also known as the file system (HDFS). <br> 
         <img src="image/HadoopEcosystem-final.jpg" style="width:1128px;height:528px";> 
          <br>
          Then there's a programming framework called Map-Reduce that sits on top of it and works with HDFS. <br>
           Hadoop, in many ways, acts as a layer between the user and the machine clusters beneath it. <br>
           <h3>HADOOP cluster</h3>
           <img src="image/e.jpg" style="width:1128px;height:528px";>  <br>
            It also contains several functions that an operating system would have, such as the ability to manage many nodes. <br>
             As a result, as a user, you won't have to worry about the many storage and processing resources that Hadoop will provide, <br>
              as they will be separated from the user's perspective. Hadoop map reduce is based on decent map reduce papers,  <br>
              and HDFS is based on Google file system. Both map reduce and HDFS work on clusters of systems, <br>
              and both have a hierarchical architecture, which means that there is a master slave model. <br>
               In general, what happens is that a large file is broken into small portions, known as blocks, <br>
                and then replicated and distributed across clusters of computers. <br>
                 This distribution is managed by Hadoop itself, so the user does not have to worry about file division and distribution. <br>
                  Internally, Hadoop manages the file system in the same way that an operating system does. <br>
                  There is one master node, known as the name node, that looks over the data distributed among the data nodes and keeps track of the distribution of the blocks,<br>
                   so the name node basically manages the file system while the data node actually stores the data blocks.<br>
                    Both name node and data node are Hadoop daemons, which are actually java programs that run on specific machines.<br>
                     However, the machines that run Hadoop daemon name node need to be more powerful than the machines that run Hadoop daemon data nodes,<br>
                      and there is a difference between the specifications and configurations of the machines.<br>
                       As a result, the physical machines are commonly referred to as name node and data nodes, <br>
                       but they are actually just java programs. Apache Hadoop is made up of two subprojects:
                      <h4>
                 MapReduce and Hadoop Distributed File System.</h4>
                 <img src="image/R.jpg" style="width:1128px;height:528px";>   <br>
                        Mapreduce is a programming methodology and software framework that aids in the development of applications that process massive volumes of data in parallel on clusters of compute nodes.<br>
                         Hadoop applications use the Hadoop Distributed File System as a storage system.<br>
                          Hadoop's popularity has skyrocketed since it now satisfies the needs of nearly every business. <br>
                          With an unrivaled price-performance curve, the Hadoop framework allows for versatile data analysis. <br>
                          The flexibility analysis feature is applicable to unstructured, semistructured, and structured data.<br>
                           In situations where enormous server farms are utilized to collect data from a variety of sources,<br>
                         the value of the Hadoop architecture has been acknowledged. <br>
                         This is due to the fact that it may handle multiple questions in parallel as massive background operations on a single server farm.<br>
                           Some tools are included in the Hadoop ecosystem to help it address specific demands. <br>
                           <img src="image/R (1).jpg" style="width:1128px;height:528px";>  <br>
                          Hive (a SQL dialect), Zookeeper (a federation service), Oozie, Avro, Thrift, and Protobuf are examples of description formats. <br>
                         Hadoop provides a number of benefits, including the ability to manage data from a variety of sources, regardless of the data's native format.<br>
                         Although data is sometimes held in unrelated systems, it is simple to dump it into the Hadoop cluster without the requirement for a schema.<br>
                        When compared to other legacy systems, Hadoop is less expensive. Given the huge data quantities that exist today, <br>
                         employing legacy systems is costly because they were not designed to handle such massive data sets.<br>
                         Hadoop is inexpensive because to its redundant data structure.<br>
                          Other older systems are installed on expensive specialist data storage systems,<br>
                         whereas the framework is installed on industry standard servers. <br>
                        Although the Hadoop framework has proven its efficiency in most organizations,<br>
                         older technologies will be necessary to complement Hadoop's use.<br>
                         Hadoop's advantages will make the technology appealing; consequently, enterprises must take use of the framework.<br>
                        By sorting and analyzing massive data with Hadoop, businesses will be able to make critical predictions.<br>
                          Hadoop is without a doubt the most important framework for structuring large data volumes.<br>
                        </div>
                    </p>
                         </div></p>
                                    </body>
                                            </html>
                                                        </div>
                                                        <div>
                                                            <div>
                                                                <div>
                                                                </form>
                                                                </div>
                                                                    </div>
                                                                        </div>
                                                                    </div>
